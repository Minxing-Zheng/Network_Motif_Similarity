Reddit Threads

Discussion and non-discussion based threads from Reddit which we collected in May 2018. Nodes are Reddit users who participate in a discussion and links are replies between them. The task is to predict whether a thread is discussion based or not (binary classification).

Properties

- Number of graphs: 203,088
- Directed: No.
- Node features: No.
- Edge features: No.
- Graph labels: Yes. Binary-labeled.
- Temporal: No.

|   Stats  |  Min  |  Max  |
|   ---    |  ---  |  ---  |
|  Nodes   |  11   |   97  | 
| Density  | 0.021 | 0.382 | 
| Diameter |   2   |   27  | 

Possible Tasks

- Graph classification
